import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    while True:

        city = str(input("Would you like to see data for Chicago, New York, or Washington ")).lower()

        if city not in CITY_DATA:
            print("enter proper input ")
            continue

        try:

            checking_filter = str(input("Would you like to filter the data by month, day, both or not at all "
                                        "Type\"none\" for no time filter "))

            if checking_filter == 'both':
                month = str(input("Which month? January, February, March, April, May, or June")).lower()
                day = int(input("Which day? Please type your response as an integer (from 0 to 6)"
                                " and Sunday equal 1"))

            if checking_filter == 'month':
                month = str(input("Which month? January, February, March, April, May, or June")).lower()
                day = 8

            if checking_filter == 'day':
                day = int(input("Which day? Please type your response as an integer (from 0 to 6)"
                                " and Sunday equal 1"))
                month='all'

            if checking_filter == 'none':
                month = 'all'
                day = 8

            break

        except:
            print("enter proper inputs")

        finally:
            print("your inputs are valid")
    # get user input for month (all, january, february, ... , june)


    # get user input for day of week (all, monday, tuesday, ... sunday)


    print('-'*40)
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """

    df = pd.read_csv(CITY_DATA[city])

    df["Start Time"] = pd.to_datetime(df["Start Time"])
    df["month"] = df["Start Time"].dt.month
    df["day_of_week"] = df["Start Time"].dt.dayofweek
    df["hour"] = df["Start Time"].dt.hour

    if month.lower() != 'all' :

        month = month.lower()
        months = ['january', 'february', 'march', 'april', 'may', 'june']
        month = months.index(month) + 1

        df = df[df['month'] == month]

    if day != 8:

        df = df[df['day_of_week'] == day]

    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month

    months = ['january', 'february', 'march', 'april', 'may', 'june']

    print("most common month is :",months[df["month"].mode()[0]-1])

    # display the most common day of week

    days = ['Saturday','Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']

    print("most common day is :",days[df["day_of_week"].mode()[0]])

    # display the most common start hour

    print("most common hour is :",df["hour"].mode()[0])

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station

    print("most commonly used start station is :",df["Start Station"].mode()[0],
          " and  its count is :",df["Start Station"].value_counts().max())

    # display most commonly used end station

    print("most commonly used end station is :", df["End Station"].mode()[0]," and  its count is :",
          df["End Station"].value_counts().max())

    # display most frequent combination of start station and end station trip

    print("most frequent combination of start station and end station trip"
          " is :",df["Start Station"].mode()[0]+"  and  "+df["End Station"].mode()[0])

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time

    print("Total travel time is :",df["Trip Duration"].sum().sum())

    # display mean travel time

    print("Mean travel time is :",df["Trip Duration"].mean())

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types

    try:
        print("Counts of User Type")
        print(df["User Type"].value_counts().index[0],"  ",df["User Type"].value_counts()[0])
        print(df["User Type"].value_counts().index[1],"  ",df["User Type"].value_counts()[1])
        print()
        # Display counts of gender

        print("Counts of Gender")
        print(df["Gender"].value_counts().index[0],"  ",df["Gender"].value_counts()[0])
        print(df["Gender"].value_counts().index[1], "  ", df["Gender"].value_counts()[1])
        print()
        # Display earliest, most recent, and most common year of birth

        print("most common year is",df["Birth Year"].mode()[0])
        print("most earliest year is",df["Birth Year"].min())
        print("most recent year is",df["Birth Year"].max())

        print("\nThis took %s seconds." % (time.time() - start_time))
        print('-'*40)

    except:
        print("there is no available information to this category")

# def prompting_raw_data(no_of_samples):
#     print(df.head(no_of_samples))

def main():

    samples = 5

    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)

        continuing = input("need raw data to be viewed? enter y (for yes) and any charchter (for no)")
        if continuing == 'y':
            print(df.head(samples))
            while True:
                continuing = input("need more raw data to be viewed? enter y (for yes) and any charchter (for no)")
                if continuing == 'y':
                    samples+=5
                    print(df.head(samples))
                else:
                    break

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
	main()
